import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GameState } from '../models/game-state';
import { Category } from '../models/category';

@Injectable({
  providedIn: 'root'
})
export class GameService {

  private apiUrl = 'http://localhost:8080/dice';

  constructor(private http: HttpClient) {}

  rollDice(): Observable<GameState> {
    return this.http.post<GameState>(
      `${this.apiUrl}/roll`,
      {}
    );
  }

  scoreCategory(category: Category): Observable<GameState> {
    return this.http.post<GameState>(
      `${this.apiUrl}/score`,
      JSON.stringify(category),
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );
  }

  newGame(): Observable<GameState> {
    return this.http.post<GameState>(
      `${this.apiUrl}/new-game`,
      {}
    );
  }

  optimal(): Observable<GameState> {
    return this.http.post<GameState>(
      `${this.apiUrl}/optimal`,
      {}
    );
  }

}
