import { Category } from './category';
import { RollEntry } from './roll-entry';
import { GamePhase } from './game-phase';
import { OptimalResult } from './optimal-result';

export interface GameState {
    currentRoll: number[];
    availableCategories: Category[];
    score: number;
    totalScore: number;
    rollHistory: RollEntry[];
    gamePhase: GamePhase;
    optimalResult: OptimalResult;
}
